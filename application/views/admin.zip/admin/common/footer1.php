    <!--Javascript-->
        <script src="<?= base_url('admin_assets'); ?>/vendors/js/vendor.bundle.addons.js"></script>
        <!--<script src="<?= base_url('demo_admin_assets'); ?>/vendors/js/vendor.bundle.base.js"></script>-->
        
        <script src="<?= base_url(); ?>/assets/front/js/customFunction.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/profile.js"></script>
        
        
        <script src="<?= base_url('admin_assets'); ?>/js/off-canvas.js"></script>
        <script src="<?= base_url('admin_assets'); ?>/js/hoverable-collapse.js"></script>
        <script src="<?= base_url('admin_assets'); ?>/js/misc.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/select2.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/settings.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/jquery.blockui.min.js"></script>
        
        <!--<script src="<?= base_url('admin_assets'); ?>/js/settings.js"></script>-->
        <script src="<?= base_url('admin_assets'); ?>/js/todolist.js"></script>
        <script src="<?= base_url('admin_assets'); ?>/js/dashboard.js"></script>
        <script src="<?= base_url('admin_assets'); ?>/js/data-table.js"></script>
        
    <!--js end-->
</body>

</html>
