    <!--Javascript-->
        
        <!--<script src="<?= base_url('admin_assets'); ?>/vendors/js/vendor.bundle.addons.js"></script>-->
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/js/vendor.bundle.base.js"></script>
        
        
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/datatables.net/jquery.dataTables.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/data-table.js"></script>
        
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/jquery-toast-plugin/jquery.toast.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/jquery-validation/jquery.validate.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/bootstrap-maxlength/bootstrap-maxlength.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/select2/select2.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/typeahead.js/typeahead.bundle.min.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/customFunction.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/profile.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/sweetalert.min.js"></script>
        
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/moment/moment.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/daterangepicker/daterangepicker.js"></script>
        
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/sweetalert/sweetalert.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/vendors/jquery.avgrund/jquery.avgrund.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/alerts.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/avgrund.js"></script>
        
        <script src="<?= base_url('demo_admin_assets'); ?>/js/off-canvas.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/hoverable-collapse.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/misc.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/settings.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/todolist.js"></script>
        <script src="<?= base_url(); ?>/assets/front/js/jquery.blockui.min.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/toastDemo.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/desktop-notification.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/file-upload.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/typeahead.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/select2.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/form-validation.js"></script>
        <script src="<?= base_url('demo_admin_assets'); ?>/js/bt-maxLength.js"></script>
    <!--js end-->
</body>

</html>
