<?php $img = $this->site_model->get_rows_d1('logo', 'device', "2", 'active', "1"); ?>
<?php 
    if (@$img) { ?>
        <img src="<?= base_url('admin_assets')  ?>/images/logo/<?= $img[0]['name']; ?>" style="margin: 0px 20px 0px; width: 30%; height: 20%;">
<?php }else{ ?>
  
<?php } ?>

<div style="background: white; padding: 110px 0px 00px;">
    <div style="padding: 0rem 0rem;background: white;margin-top: 0px; margin-bottom:0px; padding-top:80px;">
        <p style="margin: 0px 0px 5px; padding: 0px 20px; text-align: center;"><strong>TO <?php echo get_single_col_value('customer','id',$costSheetData->customer,'company_name'); ?> </strong></p>
        <p style="margin: 10px 0px 5px; padding: 0px 20px; text-align: center;"><strong>FOR <?php echo $costSheetData->name; ?></strong></p>
        <p style="margin: 10px 0px 5px; padding: 0px 20px; text-align: center;"><strong><?php echo get_single_col_value('venue','id',$costSheetData->venue,'title'); ?></strong></p>
        <div style="width:100%;text-align: left; margin-bottom: 15px; padding-top:0px; background:transparent;">
	        <table class="table table-bordered" style="border-collapse: collapse; width:100%; padding: 0px 0px 20px; margin: 20px 0px 0px; text-align: left;">
                <thead>
                    <tr>
                        <th style="border-bottom: 3px solid #a5a1a1; padding: 15px; font-size: 14px; border-left: 1px solid #a5a1a1; border-right: 1px solid #a5a1a1; border-top: 1px solid #a5a1a1;">Category</th>
                        <th style="border-bottom: 3px solid #a5a1a1; font-size: 14px; border-left: 1px solid #a5a1a1; border-right: 1px solid #a5a1a1; border-top: 1px solid #a5a1a1;">Price</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i =1; foreach ($cost_sheet_cat as $key => $value){ 
                       $alphas = range('A', 'Z'); 
                    ?>
                        <tr>
                            <td style="width:70%; border: 1px solid #a5a1a1; padding: 15px; font-size: 14px;"><?php echo $alphas[$i-1].'. '.$value['title']; ?></td>
                            <td style="width:30%; border: 1px solid #a5a1a1; text-align: center; font-size: 14px;"><?= number_format(round($value['sumSellingCost'], 3, PHP_ROUND_HALF_UP),2,'.',','); ?> <?=$costSheetData->currency ?></td>
                        </tr>
                    <?php $i++; } ?>
                    <?php  if($costSheetTotal[0]->totalCostSum!=0){ ?>
                        <h4 style=''>Total: AED <?= number_format(round($costSheetTotal[0]->sellingPriceSum,3,PHP_ROUND_HALF_UP),2,'.',','); ?> <?= $costSheetData->currency ?></h4>
                    <?php } ?>
                </tbody>
           </table>  
        </div>
    </div>
</div>