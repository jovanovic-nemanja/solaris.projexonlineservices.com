<?php $img = $this->site_model->get_rows_d1('logo', 'device', "2", 'active', "1"); ?>
<?php 
    if (@$img) { ?>
        <img src="<?= base_url('admin_assets')  ?>/images/logo/<?= $img[0]['name']; ?>" style="margin: 0px 20px 0px; width: 30%; height: 20%;">
<?php }else{ ?>
  
<?php } ?>

<div style="  width:1000px; margin: 0px auto 0px; padding: 80px 0px 00px; display: block;">
    <div style="padding: 1rem 1rem;background: white;margin-top: 0px; margin-bottom:0px; padding-top:100px;">
        <p style="margin: 10px 0px 5px; padding: 0px 20px; text-align: center;"><strong>TO <?php echo get_single_col_value('customer','id',$costSheetData->customer,'company_name'); ?> </strong></p>
        <p style="margin: 10px 0px 5px; padding: 0px 20px; text-align: center;"><strong>FOR <?php echo $costSheetData->name; ?></strong></p>
        <p style="margin: 10px 0px 5px; padding: 0px 20px; text-align: center;"><strong><?php echo get_single_col_value('venue','id',$costSheetData->venue,'title'); ?></strong></p>
        <table style="width:100%; margin:10px 0px 0px; background-color:transparent; color: black; font-weight: bold;" border="0">
            <tr>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;" colspan="5"><?php echo $costSheetData->name; ?></td>
            </tr>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">Sl. No</td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">Description</td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">Qty</td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">Unit</td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">Price</td>
            </tr>
            <?php $i =1; foreach ($cost_sheet_cat as $key => $value) { 
              $alphas = range('A', 'Z'); 
            ?>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;"><?= $alphas[$i-1] ?></td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;" colspan='3'> <?= $value['title']; ?> </td>
                
                <td style=" padding:5px; background:#ccc;">&nbsp;</td>
            </tr>
            <?php 
                $query = "select cE.id, cE.title, cE.quantity, cE.unit, (SELECT SUM(total_cost) FROM cost_sheet_line_item WHERE sub_cat_id = cE.id) as sumTotalCost, (SELECT SUM(selling_price) FROM cost_sheet_line_item WHERE sub_cat_id = cE.id) as sumSellingCost from costsheet_subcategory cE where cE.costsheet_id = '".$this->uri->segment(4)."' AND cE.cat_id = '".$value['id']."'";
                $subCategory= $this->db->query($query)->result_array();
                $j= 1; foreach ($subCategory as $key => $subvalue) {  
                $lineItems = $this->site_model->get_rows_c2('cost_sheet_line_item','cost_sheet_id',$this->uri->segment(4),'sub_cat_id',$subvalue['id']);
                ?>
            <tr>
                <td style=" padding:5px; background:#fff; border:1px solid #ccc; text-align:center;"><?= $j; ?></td>
                <td style=" padding:5px; background:#fff; border:1px solid #ccc;"><?= $subvalue['title']; ?></td>
                <td style=" padding:5px; background:#fff; border:1px solid #ccc;text-align:center;">
                    <?php if(!empty($subvalue['quantity'])) { ?>
                        <?= $subvalue['quantity']; ?>
                    <?php } ?>
                </td>
                <td style="padding:5px; background:#fff; border:1px solid #ccc; text-align:center;">
                    <?php if(!empty($subvalue['unit'])) { ?>
                        <?= $subvalue['unit']; ?>
                    <?php } ?>
                </td>
                <td style=" padding:5px; background:#fff; border:1px solid #ccc; text-align:center;"><?= $costSheetData->currency; ?> <?= number_format(round($subvalue['sumSellingCost'],3,PHP_ROUND_HALF_UP),2,'.',','); ?> </td>
            </tr>
            
           <?php $j++; } $i++; } ?>
           <tr>
                <td style="font-weight:bold; padding:5px; background:#ccc;" colspan="4">Total </td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">AED  <?= number_format(round($costSheetTotal[0]->sellingPriceSum,3,PHP_ROUND_HALF_UP),2,'.',','); ?></td>
            </tr>
           <?php 
              $disPrice = $costSheetData->discountPerent;
              $totalPrice = $costSheetTotal[0]->sellingPriceSum - $disPrice;
              $calculateVat = ((5/100)*$totalPrice);
              $totalCost = $calculateVat+$totalPrice;
              if($costSheetData->discountPerent != 0)
              {
            ?>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc;" colspan="4">Discount &nbsp;&nbsp;&nbsp;&nbsp; <?= $costSheetData->discountPerent; ?> </td>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc; text-align:center;">-AED <?= number_format(round($disPrice,3,PHP_ROUND_HALF_UP),2,'.',','); ?> </td>
            </tr>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc;" colspan="4">Total after discount</td>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc; text-align:center;">AED <?= number_format(round($totalPrice,3,PHP_ROUND_HALF_UP),2,'.',','); ?> </td>
            </tr>
            <?php } ?>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc;" colspan="4">Vat @ 5%</td>
                <td style="font-weight:bold; padding:5px; background:#fff; border:1px solid #ccc; text-align:center;">AED <?= number_format(round($calculateVat,3,PHP_ROUND_HALF_UP),2,'.',','); ?> </td>
            </tr>
            <tr>
                <td style="font-weight:bold; padding:5px; background:#ccc;" colspan="4">Total Including TAX</td>
                <td style="font-weight:bold; padding:5px; background:#ccc; text-align:center;">AED <?= number_format(round($totalCost,3,PHP_ROUND_HALF_UP),2,'.',','); ?> </td>
            </tr>
        </table>
    </div>
</div>